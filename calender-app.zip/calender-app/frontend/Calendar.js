import axios from 'axios';

export function renderCalendar() {
  axios.get('http://127.0.0.1:8000/events?view=month&date=2023-08-18')
    .then(response => {
      const events = response.data;
      const calendarElement = document.getElementById('calendar');

      events.forEach(event => {
        const eventElement = document.createElement('div');
        eventElement.className = 'event';
        eventElement.innerText = `${event.title} - ${new Date(event.date).toLocaleString()}`;
        calendarElement.appendChild(eventElement);
      });
    })
    .catch(error => console.error(error));
}
