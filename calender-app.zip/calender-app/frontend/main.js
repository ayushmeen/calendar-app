import './style.css';
import { renderCalendar } from './Calendar';

document.getElementById('app').innerHTML = `
  <h1>Dynamic Calendar Application</h1>
  <div id="calendar"></div>
`;

renderCalendar();
