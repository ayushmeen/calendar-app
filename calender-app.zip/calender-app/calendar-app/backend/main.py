from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime, timedelta

app = FastAPI()

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client.calendarDB
events_collection = db.events

# Event model
class Event(BaseModel):
    title: str
    description: str
    date: datetime
    duration: int  # Duration in minutes

# Create an event
@app.post("/events/")
async def create_event(event: Event):
    event_data = event.dict()
    result = events_collection.insert_one(event_data)
    return {"id": str(result.inserted_id)}

# Get events based on view (day, week, month)
@app.get("/events/")
async def get_events(view: str, date: datetime):
    if view == "day":
        start = date
        end = date + timedelta(days=1)
    elif view == "week":
        start = date - timedelta(days=date.weekday())
        end = start + timedelta(days=7)
    elif view == "month":
        start = date.replace(day=1)
        next_month = start.month % 12 + 1
        year = start.year + (next_month == 1)
        end = start.replace(month=next_month, year=year)
    else:
        raise HTTPException(status_code=400, detail="Invalid view")

    events = list(events_collection.find({"date": {"$gte": start, "$lt": end}}))
    for event in events:
        event["_id"] = str(event["_id"])

    return events

# Update an event
@app.put("/events/{event_id}")
async def update_event(event_id: str, event: Event):
    result = events_collection.update_one(
        {"_id": ObjectId(event_id)},
        {"$set": event.dict()}
    )
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Event not found")
    return {"status": "success"}

# Delete an event
@app.delete("/events/{event_id}")
async def delete_event(event_id: str):
    result = events_collection.delete_one({"_id": ObjectId(event_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Event not found")
    return {"status": "success"}
